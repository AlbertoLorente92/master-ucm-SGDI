Grupo 03
Hristo Ivanov Ivanov
Alberto Lorente Sánchez

===========================

En la entrega se encluye un fichero test.py que agiliza la carga de los fichero json, creando los documentos de cada colección de forma aleatoria. Además permite borrar las colecciones.

También permite testear cada función del fichero consultas.py generando ids, preguntas, tags... de forma aleatoria y devolviendo los resultados.

Se aconseja el uso del fichero test.py para generar y cargar los documentos.

Los ficheros createUser.py createResponse.py createQuestion.py son usados por test.py.

En cualquier caso de adjunta una carpeta data con ficheros json hechos a mano.
